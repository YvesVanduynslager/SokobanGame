/* Deze instructie vult de tabel Spelers op met admins */
INSERT INTO sokobandatabase.speler(gebruikernaam, wachtwoord, isAdmin, voornaam, achternaam)
VALUES ('Yves', '$2a$10$RV4IhXXJFyL3EmzvS4sqHug6mxVjM2pf8kpaFUkMM5.5yoMzXRXzK', 1, 'Yves', 'Vanduynslager'),
('Michiel', '$2a$10$RV4IhXXJFyL3EmzvS4sqHug6mxVjM2pf8kpaFUkMM5.5yoMzXRXzK', 1, 'Michiel', 'Mertens');
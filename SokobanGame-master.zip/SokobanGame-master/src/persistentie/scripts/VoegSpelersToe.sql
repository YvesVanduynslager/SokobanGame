/* Deze instructie vult de tabel Spelers op met spelers */
INSERT INTO sokobandatabase.speler(gebruikernaam, wachtwoord, isAdmin, voornaam, achternaam)
VALUES ('FrankyFishstick', '$2a$10$RV4IhXXJFyL3EmzvS4sqHug6mxVjM2pf8kpaFUkMM5.5yoMzXRXzK', 0, 'Franky', 'Fishstick'),
('RodneyRolmops', '$2a$10$RV4IhXXJFyL3EmzvS4sqHug6mxVjM2pf8kpaFUkMM5.5yoMzXRXzK', 0, 'Rodney', 'Rolmops'),
('PascalPaskotgluurder', '$2a$10$RV4IhXXJFyL3EmzvS4sqHug6mxVjM2pf8kpaFUkMM5.5yoMzXRXzK', 0, 'Pascal', 'Paskotgluurder'),
('BeatriceBokaalhoofd', '$2a$10$RV4IhXXJFyL3EmzvS4sqHug6mxVjM2pf8kpaFUkMM5.5yoMzXRXzK', 0, 'Beatrice', 'Bokaalhoofd');